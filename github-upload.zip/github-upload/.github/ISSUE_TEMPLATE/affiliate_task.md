# GitHub Issues Template - Affiliate Task

name: Affiliate Task
description: Task related to affiliate marketing implementation
title: "[AFFILIATE]: "
labels: ["affiliate", "needs assignment"]
assignees: ["fx1960"]

## Task Type
- [ ] New Affiliate Program Setup
- [ ] Affiliate Link Fix
- [ ] Conversion Optimization
- [ ] Tracking Implementation
- [ ] Promotion Campaign
- [ ] Performance Analysis
- [ ] Other (specify)

## Task Details
**Affiliate Program**: 

**Priority Level**:
- [ ] High
- [ ] Medium
- [ ] Low

**Description**:
A clear description of what needs to be done.

## Requirements
List any specific requirements for completing this task.

1. 
2. 
3. 

## Success Criteria
How will we know when this task is successfully completed?

## Deadline
When should this task be completed by?

## Additional Notes
Add any other information or context about this affiliate task.
