# GitHub Issues Template - Content Task

name: Content Task
description: Create or update content for the website
title: "[CONTENT]: "
labels: ["content", "needs assignment"]
assignees: ["fx1960"]

## Content Type
- [ ] Blog Post
- [ ] Product Review
- [ ] Tutorial
- [ ] Social Media Post
- [ ] Email Newsletter
- [ ] Video Script
- [ ] Other (specify)

## Content Details
**Title/Topic**: 

**Target Audience**: 

**Key Points to Cover**:
1. 
2. 
3. 

**SEO Keywords**:
- Primary: 
- Secondary: 

**Affiliate Products to Include**:
- 

## Content Requirements
- Word Count: 
- Images Needed: 
- Deadline: 

## Additional Notes
Add any other information or context about this content task.
