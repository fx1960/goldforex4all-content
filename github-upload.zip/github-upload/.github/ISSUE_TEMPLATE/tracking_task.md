# GitHub Issues Template - Tracking Task

name: Tracking Task
description: Task related to analytics and performance tracking
title: "[TRACKING]: "
labels: ["tracking", "analytics"]
assignees: ["fx1960"]

## Task Type
- [ ] Analytics Setup
- [ ] Dashboard Configuration
- [ ] Report Creation
- [ ] KPI Monitoring
- [ ] Conversion Tracking
- [ ] Performance Analysis
- [ ] Other (specify)

## Task Details
**Tool/Platform**: 

**Priority Level**:
- [ ] High
- [ ] Medium
- [ ] Low

**Description**:
A clear description of what needs to be done.

## Requirements
List any specific requirements for completing this task.

1. 
2. 
3. 

## Expected Outcome
What should be the result of completing this task?

## Deadline
When should this task be completed by?

## Additional Notes
Add any other information or context about this tracking task.
