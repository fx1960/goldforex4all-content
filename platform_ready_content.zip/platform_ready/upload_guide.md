# Platform Upload Guide for GoldForex4All Content

This guide provides step-by-step instructions for uploading the Week 3 content to your three platforms:
1. GitHub Repository
2. Manus Space
3. GoldForex4All Website Dashboard

## 1. GitHub Repository Upload

### Prerequisites
- GitHub account with access to https://github.com/fx1960/goldforex4all-content
- Git installed on your computer or GitHub web interface access

### Option A: Using GitHub Web Interface (Easiest)

1. Navigate to https://github.com/fx1960/goldforex4all-content
2. Click on "Add file" > "Upload files" in the repository
3. Drag and drop all the `.md` files from the `/platform_ready/manus/` folder
4. Add a commit message: "Add Week 3 content - April 2025"
5. Click "Commit changes"

### Option B: Using Git Command Line

1. Clone the repository (if not already done):
   ```
   git clone https://github.com/fx1960/goldforex4all-content.git
   cd goldforex4all-content
   ```

2. Create a new folder for Week 3 content:
   ```
   mkdir -p content/week3
   ```

3. Copy the content files:
   ```
   cp /path/to/platform_ready/manus/*.md content/week3/
   ```

4. Add, commit, and push the changes:
   ```
   git add content/week3/
   git commit -m "Add Week 3 content - April 2025"
   git push origin main
   ```

## 2. Manus Space Upload

### Automated Upload Process

The content has been specifically formatted for maximum automation in Manus Space:

1. Navigate to https://hmptxnau.manus.space/
2. Log in to your Manus account
3. Go to "Content Management" > "Import Content"
4. Select "Markdown with YAML Frontmatter" as the import format
5. Upload the `week3_content_package.md` file first - this contains the overview and metadata
6. Then upload the individual content files:
   - `risk_management_video_script.md`
   - `crypto_trading_blog_article.md`
   - `blackbull_markets_review.md`
   - `forex_market_update_social_media.md`
7. Click "Process Content" - Manus will automatically:
   - Extract metadata from YAML frontmatter
   - Categorize content by type
   - Schedule publishing based on dates in metadata
   - Apply appropriate templates
8. Review the processed content in the preview screen
9. Click "Approve" to finalize the import

### Approval Workflow

Once content is imported, you'll receive approval notifications:

1. Go to "Content Management" > "Approval Queue"
2. Review each content item (they'll be formatted according to platform standards)
3. Click "Approve" or "Request Changes" for each item
4. Approved content will be automatically scheduled according to the dates in the YAML frontmatter

## 3. GoldForex4All Website Dashboard

### Content Upload Process

1. Navigate to https://www.goldforex4all.eu/dashboard-content
2. Log in to your website admin dashboard
3. For each content type, follow the specific instructions below:

#### Blog Articles (Crypto Trading & BlackBull Markets Review)

1. Go to "Posts" > "Add New"
2. Copy the title from the markdown file
3. In the WordPress editor, switch to "Code Editor" mode
4. Copy everything below the YAML frontmatter (after the second `---` line)
5. Paste into the editor
6. Add featured image (use the filename specified in the frontmatter)
7. Set categories and tags as specified in the YAML frontmatter
8. Schedule publishing date as specified in the frontmatter
9. Click "Publish" or "Schedule"

#### Video Content (Risk Management Script)

1. Go to "Videos" > "Add New"
2. Enter the title from the markdown file
3. In the "Script" tab, paste the content from the markdown file
4. Set the video duration, categories, and tags as specified in the frontmatter
5. Upload the thumbnail image specified in the frontmatter
6. Schedule publishing date as specified
7. Click "Save" or "Schedule"

#### Social Media Content

1. Go to "Social Media" > "Schedule Posts"
2. For each platform (Instagram, Twitter, Facebook):
   - Create new scheduled post
   - Copy the platform-specific content from the markdown file
   - Upload the associated images
   - Set publishing date and time as recommended in the content
   - Add hashtags as provided
3. Click "Schedule All" to queue all social media posts

## Automation Recommendations

To maximize automation for future content:

1. **GitHub Integration**: Set up GitHub Actions to automatically deploy content from your repository to your website when new content is pushed.

2. **Manus API Integration**: Implement the Manus API to programmatically upload content packages without manual intervention.

3. **Content Scheduling**: Use the publishing dates in the YAML frontmatter to automatically schedule all content across platforms.

4. **Approval Workflow**: Configure email notifications for content approval requests to streamline the review process.

5. **Analytics Integration**: Connect analytics tracking to monitor performance of published content across all platforms.

By following these recommendations, you can create a workflow where you only need to approve content, with all technical aspects of uploading and publishing handled automatically.

## Support Resources

If you encounter any issues with the upload process:

- GitHub Help: https://docs.github.com/en
- Manus Support: https://support.manus.space
- WordPress Documentation: https://wordpress.org/support/

For specific questions about the content formatting or structure, please reach out for assistance.
